/* By: 			|	Ghost DEV 					|
/*=================================================================*/


var staff_team = [

	{
		"name":"Ghost",
		"image":"https://cdn.discordapp.com/avatars/988391380307030056/be1f2a166f75f285db26e30d3c64ea8c.gif?size=1024",
		"rank":"DEVLOPER"
	},
	//{
	//	"name":"",
	//	"image":"",
	//	"rank":""
	//},
	// {
	// 	"name":"",
	// 	"image":"",
	// 	"rank":""
	// },

]


// Staff Settings
const showStaffTeam = true
const showPlayersList = false


// orange
// red
// blue
// green
// pink
// purple
const theme = "blue"

// ==== WINTER UPDATE !! ==== \\
const enableWinterUpdate = false
// ==== WINTER UPDATE !! ==== \\


// Text settings
const name = "<strong>Ghost</strong>Dev"
const underName = ""
const desc = "Hey there, future citizen of Los Santos! We're excited to have you join our vibrant community of roleplayers, where the streets are alive with action, drama, and endless possibilities. Whether you're a seasoned roleplayer or new to the scene, there's a place for you here!"


// Social media
const discord = "https://discord.gg/nCDrSnZ8GR"  // If = "" then icon will not show up on screen
const instagram = ""	// https://example.com
const youtube = "" 		// https://example.com
const twitter = "" 		// https://example.com
const tiktok = ""  		// https://example.com
const facebook = ""		// https://example.com
const twitch = "" 		// https://example.com
const github = "" 		// https://example.com
const patreon = "" 		// https://example.com



// Player List
const serverCode = "r4l897" //Your server CODE from fivem. (cfx.re/join/94lxza) this 94lxza is your code, paste it in serverCode. 
const playerProfileImage = "https://cdn.discordapp.com/attachments/1429035347068588122/1430256359466864700/logo.png?ex=68fb17c8&is=68f9c648&hm=16ab48ac8f12ef37d5d2a334228d927bede931bc86e9634958561f6ae644e7f3&"


// Video Settings
const videoBlur = 0
var videoOpacity = 0


// Example link: https://www.youtube.com/watch?v=abcdefgh
const youtubeVideo = "https://www.youtube.com/watch?v=YeZrFMh6FiM"
const showYoutubeVideo = true

// Local Video
const enableLocalVideo = false

// Local audio
const localAudio = true



// HELP //

//-- YOUTBE
//-- LOCAL AUDIO
// if localAudio is true, then loading will load "audio.mp3" file and play it except youtube audio.
// if localAudio is false, then loading will load youtube audio.

//-- LOCAL VIDEO
// if enableLocalVideo is true, then loading will load "video.webm" file and play it except youtube video.
// If localVideo is enabled, showYoutubeVideo is automatically disabled.
// You can only import a video from either YouTube or local. Local video taking priority.