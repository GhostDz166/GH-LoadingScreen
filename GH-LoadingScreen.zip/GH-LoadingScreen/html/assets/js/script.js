$(".center h1").html(name)
$(".center p").html(underName)
$(".center span").html(desc)
var serverInfo = null

// Advanced loading status messages
const loadingMessages = [
    "Initializing server connection...",
    "Establishing secure channel...",
    "Connecting to database...",
    "Loading game resources...",
    "Configuring environment...",
    "Preparing world elements...",
    "Loading player data...",
    "Syncing with server...",
    "Initializing scripts...",
    "Finalizing connection...",
    "Validating game files...",
    "Downloading additional assets...",
    "Processing textures...",
    "Loading vehicle modifications...",
    "Initializing game world...",
    "Preparing custom resources...",
    "Loading player inventory...",
    "Synchronizing player data...",
    "Loading map modifications...",
    "Preparing gameplay elements...",
    "Configuring server settings...",
    "Processing character data...",
    "Loading weapon modifications...",
    "Initializing economy system...",
    "Verifying network connection...",
    "Processing server resources...",
    "Loading user interface...",
    "Configuring gameplay settings...",
    "Initializing server plugins...",
    "Loading custom scripts..."
];

// Connection status messages
const connectionMessages = [
    "Establishing secure connection...",
    "Verifying credentials...",
    "Connection established",
    "Synchronizing data..."
];

// Resource status messages
const resourceMessages = [
    "Loading essential resources",
    "Processing core files...",
    "Configuring server elements",
    "Finalizing resource setup"
];

// Initialize advanced progress effects
let progressGlowInterval;
let messageUpdateInterval;
let currentMessageIndex = 0;

function initProgressEffects() {
    // Subtle progress bar pulsing effect
    progressGlowInterval = setInterval(() => {
        $("#progress-bar-fill").addClass("glow-pulse");
        setTimeout(() => {
            $("#progress-bar-fill").removeClass("glow-pulse");
        }, 750);
    }, 3000);
    
    // Continuously rotate through random loading messages every 4 seconds
    messageUpdateInterval = setInterval(() => {
        // Fade out current message
        $("#loading-message").addClass("animate");
        
        // After animation completes, change text and remove animation class
        setTimeout(() => {
            // Get random message that's different from the current one
            let newIndex;
            do {
                newIndex = Math.floor(Math.random() * loadingMessages.length);
            } while (newIndex === currentMessageIndex && loadingMessages.length > 1);
            
            currentMessageIndex = newIndex;
            $("#loading-message").text(loadingMessages[currentMessageIndex]);
            $("#loading-message").removeClass("animate");
        }, 1500);
    }, 4000); // Changed from 3000 to 4000 ms (4 seconds)
    
    // Update connection status
    setTimeout(() => {
        $("#detail-left").text(connectionMessages[1]);
    }, 2000);
    
    setTimeout(() => {
        $("#detail-left").text(connectionMessages[2]);
        $("#detail-left").css("color", "rgba(var(--main), 1)");
    }, 4000);
    
    setTimeout(() => {
        $("#detail-right").text(resourceMessages[1]);
    }, 6000);
}

// Modern loading function with smooth animation
function loading(num) {
    // Don't stop message rotation - let it continue
    // if (messageUpdateInterval) clearInterval(messageUpdateInterval);
    
    // Current progress
    let current = parseInt($("#progress-percentage").text(), 10) || 0;
    const step = 1;
    const delay = 25; // Smoother animation with smaller delay
    
    // We don't update the message here anymore, as it's handled by the interval
    // But we still update the resource status based on progress
    if (num > 40 && num < 70) {
        $("#detail-right").text(resourceMessages[2]);
    } else if (num >= 70) {
        $("#detail-right").text(resourceMessages[3]);
        $("#detail-right").css("color", "rgba(var(--main), 1)");
        $("#detail-left").text(connectionMessages[3]);
    }
    
    // Smooth animation loop for progress bar
    const interval = setInterval(function() {
        if (current < num) {
            current += step;
            if (current > num) current = num;
        } else if (current > num) {
            current -= step;
            if (current < num) current = num;
        } else {
            clearInterval(interval);
        }
        
        // Update percentage display and progress bar width
        $("#progress-percentage").text(current + "%");
        $("#progress-bar-fill").css("width", current + "%");
        
        // Add milestone effects at significant progress points
        if (current % 25 === 0) {
            $("#progress-bar-fill").addClass("milestone-achieved");
            setTimeout(() => {
                $("#progress-bar-fill").removeClass("milestone-achieved");
            }, 500);
        }
    }, delay);
}

// Initialize on document ready
$(document).ready(function() {
    initProgressEffects();
    // Start with minimal progress
    loading(1);
});

if (showStaffTeam) {
    $(".panel.staffteam").show()
    $(".panel.devteam").show()

    staff_team.forEach(function(user) {
        let userHtml = `
            <div class="staff">
                <div class="info">
                    <img src="${user.image}" class="pfp">
                    <p>${user.name}</p>
                </div>
                <p class="status">${user.rank}</p>
            </div>
        `;

        if (user.rank.toLowerCase() === "developer") {
            $(".dev_team").append(userHtml)
        } else {
            $(".staff_team").append(userHtml)
        }
    });
}



if (showPlayersList){
	$(".panel.playerlist").show()
	players()
}

function players(){
	if (serverCode == "******"){return}
	$.get("https://servers-frontend.fivem.net/api/servers/single/"+serverCode,function(data){
		serverInfo = data.Data
		serverInfo.players.forEach(function(player){
			$(".player_list").append(`
				<div class="staff">
					<div class="info">
						<img src="${playerProfileImage}" class="pfp">
						<p>${player.name}</p>
					</div>
					<p class="status">ID: ${player.id}</p>
				</div>
			`)
		})
	})
}

// Handle FiveM loading progress events
window.addEventListener('message', function(e) {
    if(e.data.eventName === 'loadProgress') {
    	var num = (e.data.loadFraction * 100).toFixed(0);
        loading(num);
    }
});

const socials = { discord, instagram, youtube, twitter, tiktok, facebook, twitch, github, patreon };
const platforms = ["discord", "instagram", "youtube", "twitter", "tiktok", "facebook", "twitch", "github", "patreon"];

platforms.forEach(platform => {
	if (socials[platform] != "") {
		$(`.${platform}`).show();
		$(`.${platform} a`).attr("href", socials[platform]);
	}
});

$("a").on("click",function(e){
	e.preventDefault()
	window.invokeNative('openUrl', e.target.href)
})

if (theme == "orange"){
	$("body").append(`<style>:root{--main:255, 150, 0;}</style>`)
	$("body").css("background-image","url('assets/img/orange.jpg')")
	$(".winter").css("background","linear-gradient(0deg, rgb(255 150 0 / 10%) 0%, rgba(255, 150, 0, 0.0) 100%)")
}
if (theme == "red"){
	$("body").append(`<style>:root{--main:255,0,0;}</style>`)
	$("body").css("background-image","url('assets/img/red.jpg')")
	$(".winter").css("background","linear-gradient(0deg, rgb(255 0 0 / 10%) 0%, rgba(255, 0, 0, 0.0) 100%)")
}
if (theme == "blue"){
	$("body").append(`<style>:root{--main:0, 163, 255;}</style>`)
	$("body").css("background-image","url('assets/img/blue.jpg')")
	$(".winter").css("background","linear-gradient(0deg, rgb(0 163 255 / 10%) 0%, rgba(0, 163, 255, 0.0) 100%)")
}
if (theme == "green"){
	$("body").append(`<style>:root{--main:124, 205, 124;}</style>`)
	$("body").css("background-image","url('assets/img/green.jpg')")
	$(".winter").css("background","linear-gradient(0deg, rgb(124 205 124 / 10%) 0%, rgba(124, 205, 124, 0.0) 100%)")
}
if (theme == "pink"){
	$("body").append(`<style>:root{--main:255, 183, 197;}</style>`)
	$("body").css("background-image","url('assets/img/pink.jpg')") // تأكد أنك تضيف الصورة بهذا الاسم
	$(".winter").css("background","linear-gradient(0deg, rgb(255 183 197 / 10%) 0%, rgba(255, 183, 197, 0.0) 100%)")
}
if (theme == "purple"){
	$("body").append(`<style>:root{--main:193, 67, 255;}</style>`)
	$("body").css("background-image","url('assets/img/purple.jpg')")
	$(".winter").css("background","linear-gradient(0deg, rgb(193 67 255 / 10%) 0%, rgba(193, 67, 255, 0.0) 100%)")
}
// Winter update
if (enableWinterUpdate){
	particlesJS("particles-js", { "particles": { "number": { "value": 160, "density": { "enable": true, "value_area": 800 } }, "color": { "value": "#ffffff" }, "shape": { "type": "circle", "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": 0.5, "random": false, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": 3, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": false, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 1.5, "direction": "bottom", "random": true, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": true, "rotateX": 100, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": false, "mode": "repulse" }, "onclick": { "enable": false, "mode": "repulse" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 223.7762237762238, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });
	$("body").css("background-image","url('assets/img/winter.jpg')")
	$(".winter").css("display","flex")
	$("#particles-js").css("opacity",1)
}

let a, vl, yt, isMute = false, isPaused = false;
let player;

// Set up YouTube player with YouTube IFrame API - better method than iframe directly
function onYouTubeIframeAPIReady() {
    if (youtubeVideo.startsWith("https://www.youtube.com") && !enableLocalVideo) {
        const videoId = youtubeVideo.split('/').pop().split('=')[1];
        
        player = new YT.Player('youtube-player', {
            width: '150%', // Larger than container to hide UI elements
            height: '150%',
            videoId: videoId,
            playerVars: {
                'autoplay': 1,
                'controls': 0,
                'disablekb': 1,
                'enablejsapi': 1,
                'fs': 0,
                'modestbranding': 1,
                'loop': 1,
                'playlist': videoId,
                'rel': 0,
                'showinfo': 0,
                'iv_load_policy': 3,
                'mute': localAudio ? 1 : 0,
                'autohide': 1,
                'playsinline': 1,
                'origin': window.location.origin,
                'widget_referrer': window.location.href,
                'cc_load_policy': 0
            },
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onPlayerStateChange,
                'onError': onPlayerError
            }
        });
        
        if (showYoutubeVideo) {
            $("body").css("background", "#000");
        } else {
            $("#youtube-container").css("opacity", 0);
        }
        
        yt = player; // For compatibility with existing functions
        
        // Add extra protections to hide YouTube UI elements
        setTimeout(function() {
            // Add a click handler to prevent YouTube UI from showing
            $("#youtube-container").on('click', function(e) {
                e.preventDefault();
                if (isPaused) {
                    player.playVideo();
                    isPaused = false;
                    $('#play-pause-btn i').removeClass('bi-play-fill').addClass('bi-pause-fill');
                } else {
                    player.pauseVideo();
                    isPaused = true;
                    $('#play-pause-btn i').removeClass('bi-pause-fill').addClass('bi-play-fill');
                }
                return false;
            });
        }, 1000);
    }
}

function onPlayerReady(event) {
    if (localAudio) {
        event.target.mute();
    } else {
        event.target.unMute();
    }
    
    // Set player quality to high definition if available
    event.target.setPlaybackQuality('hd1080');
    
    // Start playback
    event.target.playVideo();
    
    // Hide YouTube UI elements using additional CSS
    hideYouTubeUI();
    
    // Continue to hide YouTube UI elements that might reappear
    setInterval(hideYouTubeUI, 1000);
}

// Function to hide YouTube UI elements
function hideYouTubeUI() {
    // Try to access the iframe's document
    try {
        const iframe = document.querySelector('#youtube-player');
        if (!iframe) return;
        
        // Check if we can access iframe content
        const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
        if (!iframeDocument) return;
        
        // Add CSS to hide all YouTube UI elements
        const style = iframeDocument.createElement('style');
        style.textContent = `
            .ytp-chrome-top, 
            .ytp-chrome-bottom, 
            .ytp-pause-overlay, 
            .ytp-large-play-button,
            .ytp-gradient-top,
            .ytp-gradient-bottom,
            .ytp-watermark,
            .ytp-title,
            .ytp-title-text,
            .ytp-share-button,
            .ytp-watch-later-button,
            .ytp-chrome-controls,
            .ytp-pause-overlay-container,
            .ytp-spinner {
                display: none !important;
                opacity: 0 !important;
                visibility: hidden !important;
            }
        `;
        
        // Append style to iframe document if not already added
        if (!iframeDocument.querySelector('#youtube-ui-hider')) {
            style.id = 'youtube-ui-hider';
            iframeDocument.head.appendChild(style);
        }
    } catch (e) {
        // Cannot access iframe content due to same-origin policy
        // This is expected, and we'll rely on CSS approach instead
    }
}

// Ensure video loops when it ends
function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.ENDED) {
        event.target.playVideo();
    }
}

// Log any player errors
function onPlayerError(event) {
    console.error("YouTube player error:", event.data);
}

// Handle local media
$(document).ready(function() {
    if (localAudio) {
        $('body').append('<audio id="audioPlayer" src="audio.mp3" loop></audio>');
        $('#audioPlayer')[0].play().catch(error => {
            console.error("Audio autoplay error:", error);
            // Try again when user interacts with the page
            $(document).one('click', function() {
                $('#audioPlayer')[0].play();
            });
        });
        a = $('#audioPlayer');
    }

    if (enableLocalVideo) {
        $('body').append('<video id="videoPlayer" autoplay loop muted><source src="video.webm" type="video/webm"></video>');
        const video = $('#videoPlayer')[0];
        
        video.play().catch(error => {
            console.error("Video autoplay error:", error);
            // Try again when user interacts with the page
            $(document).one('click', function() {
                video.play();
            });
        });
        
        vl = $('#videoPlayer');
        if (localAudio) {
            vl[0].muted = true;
        }
        $("body").css("background", "#000");
    }
    
    // Initialize music player
    initMusicPlayer();
});

function toggleMute(button) {
    isMute = !isMute;
    
    // Update volume icon
    if (isMute) {
        $('#volume-btn i').removeClass('bi-volume-up').addClass('bi-volume-mute');
    } else {
        $('#volume-btn i').removeClass('bi-volume-mute').addClass('bi-volume-up');
    }
    
    // Handle YouTube player
    if (player && typeof player.mute === "function") {
        localAudio ? player.mute() : (isMute ? player.mute() : player.unMute());
    }
    
    // Handle audio element
    if (a && a[0]) { 
        a[0].muted = isMute; 
    }
    
    // Handle video element
    if (vl && vl[0]) { 
        if (localAudio){
            vl[0].muted = true;
        } else {
            vl[0].muted = isMute; 
        }
    }
}

function togglePause(button) {
    isPaused = !isPaused;
    
    // Update play/pause icon
    if (isPaused) {
        $('#play-pause-btn i').removeClass('bi-pause-fill').addClass('bi-play-fill');
    } else {
        $('#play-pause-btn i').removeClass('bi-play-fill').addClass('bi-pause-fill');
    }
    
    // Handle audio element
    if (a && a[0]) { 
        isPaused ? a[0].pause() : a[0].play(); 
    }
    
    // Handle video element (but NOT YouTube player)
    if (vl && vl[0] && !localAudio) { 
        isPaused ? vl[0].pause() : vl[0].play(); 
    }
    
    // Toggle equalizer animation
    if (isPaused) {
        $('.equalizer span').css('animation-play-state', 'paused');
    } else {
        $('.equalizer span').css('animation-play-state', 'running');
        startProgressUpdate();
    }
}

function setVolume(volume) {
    // Handle audio element
    if (a && a[0]) { 
        a[0].volume = volume / 100; 
    }
    
    // Handle video element (only if it's the audio source)
    if (vl && vl[0] && !localAudio) { 
        vl[0].volume = volume / 100; 
    }
}

function setVolume(volume) {
    // Handle audio element
    if (a && a[0]) { 
        a[0].volume = volume / 100; 
    }
    
    // Handle video element
    if (vl && vl[0]) { 
        vl[0].volume = volume / 100; 
    }
    
    // Handle YouTube player
    if (player && !localAudio) {
        player.setVolume(volume);
    }
}

// Music player additional functions
let progressInterval;

function initMusicPlayer() {
    // Initialize progress bar functionality
    $('.progress-container').on('click', function(e) {
        seekTrack(e);
    });
    
    // Initialize player display
    updatePlayerDisplay();
    
    // Start progress tracking
    startProgressUpdate();
    
    // Enable dragging functionality for progress handle
    let isDragging = false;
    
    $('.progress-container').on('mousedown', function(e) {
        isDragging = true;
        seekTrack(e);
    });
    
    $(document).on('mousemove', function(e) {
        if (isDragging) {
            seekTrack(e);
        }
    });
    
    $(document).on('mouseup', function() {
        isDragging = false;
    });
}

function updatePlayerDisplay() {
    // Set default track info based on your configuration
    const trackInfo = {
        title: "BT MUSIC",
        artist: "BT DEV TEAM",
        duration: 180 // example duration in seconds
    };
    
    // Update display
    $('#track-title').text(trackInfo.title);
    $('#track-artist').text(trackInfo.artist);
    
    // Check if we can get actual duration from audio/video
    let duration = trackInfo.duration;
    if (a && a[0] && a[0].duration && !isNaN(a[0].duration)) {
        duration = Math.floor(a[0].duration);
    } else if (vl && vl[0] && vl[0].duration && !isNaN(vl[0].duration)) {
        duration = Math.floor(vl[0].duration);
    } else if (player && typeof player.getDuration === "function") {
        duration = player.getDuration();
    }
    
    // Format and display duration
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    $('#duration').text(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
}

function startProgressUpdate() {
    if (progressInterval) clearInterval(progressInterval);
    
    progressInterval = setInterval(() => {
        if (isPaused) return;
        
        let currentTime = 0;
        let duration = 180; // Default duration
        
        // Get current time and duration from actual media source
        if (a && a[0]) {
            currentTime = a[0].currentTime;
            duration = a[0].duration || duration;
        } else if (vl && vl[0]) {
            currentTime = vl[0].currentTime;
            duration = vl[0].duration || duration;
        } else if (player && typeof player.getCurrentTime === "function") {
            currentTime = player.getCurrentTime();
            duration = player.getDuration() || duration;
        }
        
        // Update progress bar
        const percentage = (currentTime / duration) * 100;
        $('#progress').css('width', `${percentage}%`);
        
        // Update time display
        const minutes = Math.floor(currentTime / 60);
        const seconds = Math.floor(currentTime % 60);
        $('#current-time').text(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        
        // Position the progress handle
        updateProgressHandlePosition(percentage);
    }, 1000);
}

function updateProgressHandlePosition(percentage) {
    const progressWidth = $('.progress-bar').width();
    const handlePosition = (percentage / 100) * progressWidth;
    $('.progress-handle').css('left', `${handlePosition}px`);
}

function prevTrack() {
    // Reset to beginning of track
    if (a && a[0]) { a[0].currentTime = 0; }
    if (vl && vl[0]) { vl[0].currentTime = 0; }
    if (player && typeof player.seekTo === "function") { player.seekTo(0); }
    
    // Reset progress display
    $('#progress').css('width', '0%');
    $('#current-time').text('00:00');
    updateProgressHandlePosition(0);
}

function nextTrack() {
    // Since we only have one track, just reset to beginning
    prevTrack();
}

function seekTrack(e) {
    const progressContainer = $('.progress-container');
    const clickPosition = e.pageX - progressContainer.offset().left;
    const percentage = (clickPosition / progressContainer.width()) * 100;
    
    // Update visual progress
    $('#progress').css('width', `${percentage}%`);
    updateProgressHandlePosition(percentage);
    
    // Get duration
    let duration = 180;
    if (a && a[0] && a[0].duration) {
        duration = a[0].duration;
    } else if (vl && vl[0] && vl[0].duration) {
        duration = vl[0].duration;
    } else if (player && typeof player.getDuration === "function") {
        duration = player.getDuration();
    }
    
    // Calculate time based on percentage and update the player
    const newTime = (percentage / 100) * duration;
    
    // Update time display
    const minutes = Math.floor(newTime / 60);
    const seconds = Math.floor(newTime % 60);
    $('#current-time').text(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    
    // Seek in the actual audio/video player
    if (a && a[0]) { a[0].currentTime = newTime; }
    if (vl && vl[0]) { vl[0].currentTime = newTime; }
    if (player && typeof player.seekTo === "function") { player.seekTo(newTime); }
}